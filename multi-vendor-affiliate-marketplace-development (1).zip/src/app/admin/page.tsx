"use client";

import { useState, useEffect } from "react";

type Product = { id: number; name: string; description: string | null; price: number; image: string | null; isBestseller: boolean | null; stock: number | null };
type Shop = { id: number; name: string; slug: string; image: string | null; bannerImage: string | null; commissionRate: number | null; totalEarnings: number | null; paidEarnings: number | null };
type Order = { id: number; customerId: number; shopId: number; customerName: string; customerPhone: string; customerAddress: string; shippingMethod: string; totalAmount: number; commissionAmount: number | null; status: string | null; trackingLink: string | null; items: any; createdAt: string | null };

function formatPrice(price: number) { return new Intl.NumberFormat("fa-IR").format(price) + " تومان"; }

const SvgIcons = {
  dashboard: <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6A2.25 2.25 0 0 1 6 3.75h2.25A2.25 2.25 0 0 1 10.5 6v2.25a2.25 2.25 0 0 1-2.25 2.25H6a2.25 2.25 0 0 1-2.25-2.25V6ZM3.75 15.75A2.25 2.25 0 0 1 6 13.5h2.25a2.25 2.25 0 0 1 2.25 2.25V18a2.25 2.25 0 0 1-2.25 2.25H6A2.25 2.25 0 0 1 3.75 18v-2.25ZM13.5 6a2.25 2.25 0 0 1 2.25-2.25H18A2.25 2.25 0 0 1 20.25 6v2.25A2.25 2.25 0 0 1 18 10.5h-2.25a2.25 2.25 0 0 1-2.25-2.25V6ZM13.5 15.75a2.25 2.25 0 0 1 2.25-2.25H18a2.25 2.25 0 0 1 2.25 2.25V18A2.25 2.25 0 0 1 18 20.25h-2.25a2.25 2.25 0 0 1-2.25-2.25v-2.25Z" /></svg>,
  products: <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="m20.25 7.5-.625 10.632a2.25 2.25 0 0 1-2.247 2.118H6.622a2.25 2.25 0 0 1-2.247-2.118L3.75 7.5m8.25 3v6.75m0 0-3-3m3 3 3-3M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125Z" /></svg>,
  shops: <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M13.5 21v-7.5a.75.75 0 0 1 .75-.75h3a.75.75 0 0 1 .75.75V21m-4.5 0H2.36m11.14 0H18m0 0h3.64m-1.39 0V9.349M3.75 21V9.349m0 0a3.001 3.001 0 0 0 3.75-.615A2.993 2.993 0 0 0 9.75 9.75c.896 0 1.7-.393 2.25-1.016a2.993 2.993 0 0 0 2.25 1.016c.896 0 1.7-.393 2.25-1.015a3.001 3.001 0 0 0 3.75.614m-16.5 0a3.004 3.004 0 0 1-.621-4.72l1.189-1.19A1.5 1.5 0 0 1 5.378 3h13.243a1.5 1.5 0 0 1 1.06.44l1.19 1.189a3 3 0 0 1-.621 4.72M6.75 18h3.75a.75.75 0 0 0 .75-.75V13.5a.75.75 0 0 0-.75-.75H6.75a.75.75 0 0 0-.75.75v3.75c0 .414.336.75.75.75Z" /></svg>,
  orders: <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 0 0-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 0 0-16.536-1.84M7.5 14.25 5.106 5.272M6 20.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm12.75 0a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" /></svg>,
  payouts: <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18.75a60.07 60.07 0 0 1 15.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 0 1 3 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 0 0-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 0 1-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 0 0 3 15h-.75M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm3 0h.008v.008H18V10.5Zm-12 0h.008v.008H6V10.5Z" /></svg>,
  banners: <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Zm10.5-11.25h.008v.008h-.008V8.25Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" /></svg>,
  settings: <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.325.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 0 1 1.37.49l1.296 2.247a1.125 1.125 0 0 1-.26 1.431l-1.003.827c-.293.241-.438.613-.43.992a7.723 7.723 0 0 1 0 .255c-.008.378.137.75.43.991l1.004.827c.424.35.534.955.26 1.43l-1.298 2.247a1.125 1.125 0 0 1-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.47 6.47 0 0 1-.22.128c-.331.183-.581.495-.644.869l-.213 1.281c-.09.543-.56.94-1.11.94h-2.594c-.55 0-1.019-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 0 1-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 0 1-1.369-.49l-1.297-2.247a1.125 1.125 0 0 1 .26-1.431l1.004-.827c.292-.24.437-.613.43-.991a6.932 6.932 0 0 1 0-.255c.007-.38-.138-.751-.43-.992l-1.004-.827a1.125 1.125 0 0 1-.26-1.43l1.297-2.247a1.125 1.125 0 0 1 1.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.086.22-.128.332-.183.582-.495.644-.869l.214-1.28Z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" /></svg>,
  logout: <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9" /></svg>,
  edit: <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10" /></svg>,
  trash: <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" /></svg>,
  close: <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" /></svg>,
  menu: <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" /></svg>,
};

export default function AdminDashboard() {
  const [activeSection, setActiveSection] = useState("dashboard");
  const [products, setProducts] = useState<Product[]>([]);
  const [shops, setShops] = useState<Shop[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [sliderBanners, setSliderBanners] = useState<any[]>([]);
  const [bottomBanners, setBottomBanners] = useState<any[]>([]);
  const [editProduct, setEditProduct] = useState<any>(null);
  const [editShop, setEditShop] = useState<any>(null);
  const [editOrder, setEditOrder] = useState<any>(null);
  const [payoutForm, setPayoutForm] = useState({ shopId: 0, amount: 0, description: "" });
  const [newBanner, setNewBanner] = useState({ type: "slider", image: "", sortOrder: 0 });
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => {
    try {
      const [pRes, sRes, oRes, stRes, bRes] = await Promise.all([
        fetch("/api/products"), fetch("/api/shops"), fetch("/api/orders"), fetch("/api/settings"), fetch("/api/banners"),
      ]);
      setProducts(await pRes.json());
      setShops(await sRes.json());
      const od = await oRes.json(); setOrders(Array.isArray(od) ? od : []);
      setSettings(await stRes.json());
      const bd = await bRes.json(); setSliderBanners(bd.sliders || []); setBottomBanners(bd.bottoms || []);
    } catch (err) { console.error(err); }
  };

  const saveProduct = async () => { if (!editProduct) return; await fetch("/api/products", { method: editProduct.id ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(editProduct) }); setEditProduct(null); loadAll(); };
  const deleteProduct = async (id: number) => { if (!confirm("حذف شود؟")) return; await fetch("/api/products", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) }); loadAll(); };
  const saveShop = async () => { if (!editShop) return; await fetch("/api/shops", { method: editShop.id ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(editShop) }); setEditShop(null); loadAll(); };
  const updateOrder = async () => { if (!editOrder) return; await fetch("/api/orders", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: editOrder.id, status: editOrder.status, trackingLink: editOrder.trackingLink }) }); setEditOrder(null); loadAll(); };
  const processPayout = async () => { await fetch("/api/payouts", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payoutForm) }); setPayoutForm({ shopId: 0, amount: 0, description: "" }); loadAll(); };
  const saveSettings = async () => { await fetch("/api/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(settings) }); alert("تنظیمات ذخیره شد"); };
  const addBanner = async () => { if (!newBanner.image) return; await fetch("/api/banners", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(newBanner) }); setNewBanner({ type: "slider", image: "", sortOrder: 0 }); loadAll(); };
  const deleteBanner = async (type: string, id: number) => { await fetch("/api/banners", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type, id }) }); loadAll(); };
  const logout = async () => { await fetch("/api/auth/logout", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: "admin" }) }); window.location.href = "/admin/login"; };

  const primary = settings.primary_color || "#FF1744";
  const secondary = settings.secondary_color || "#37474F";

  const menuItems = [
    { key: "dashboard", icon: SvgIcons.dashboard, label: "داشبورد" },
    { key: "products", icon: SvgIcons.products, label: "محصولات" },
    { key: "shops", icon: SvgIcons.shops, label: "فروشگاه‌ها" },
    { key: "orders", icon: SvgIcons.orders, label: "سفارش‌ها" },
    { key: "payouts", icon: SvgIcons.payouts, label: "پورسانت‌ها" },
    { key: "banners", icon: SvgIcons.banners, label: "بنرها" },
    { key: "settings", icon: SvgIcons.settings, label: "تنظیمات" },
  ];

  const inputClass = "w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-100 text-sm focus:ring-2 transition-all";

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex" dir="rtl">
      {/* Mobile menu */}
      <button onClick={() => setSidebarOpen(!sidebarOpen)} className="fixed top-4 right-4 z-50 lg:hidden w-10 h-10 rounded-xl bg-white shadow-md flex items-center justify-center text-gray-600">
        {SvgIcons.menu}
      </button>

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 right-0 z-40 w-60 transform transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"}`}
        style={{ background: secondary }}>
        <div className="p-5">
          <div className="mb-8 mt-2">
            <p className="text-[10px] font-bold tracking-[0.2em] text-white/40 mb-1">ADMIN PANEL</p>
            <h1 className="text-base font-black text-white">پنل مدیریت</h1>
          </div>
          <nav className="space-y-0.5">
            {menuItems.map((item) => (
              <button key={item.key} onClick={() => { setActiveSection(item.key); setSidebarOpen(false); }}
                className={`w-full text-right px-3.5 py-2.5 rounded-xl transition-all flex items-center gap-2.5 text-sm ${activeSection === item.key ? "text-white font-bold" : "text-white/50 hover:text-white/80 hover:bg-white/5"}`}
                style={{ background: activeSection === item.key ? primary : "transparent" }}>
                {item.icon}
                <span>{item.label}</span>
              </button>
            ))}
          </nav>
          <button onClick={logout}
            className="w-full mt-8 px-3.5 py-2.5 rounded-xl text-white/40 hover:text-white/70 hover:bg-white/5 text-right flex items-center gap-2.5 text-sm transition-all">
            {SvgIcons.logout}
            <span>خروج</span>
          </button>
        </div>
      </aside>

      {sidebarOpen && <div className="fixed inset-0 bg-black/30 z-30 lg:hidden backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />}

      {/* Main */}
      <main className="flex-1 p-4 lg:p-7 overflow-auto min-h-screen">
        {/* Dashboard */}
        {activeSection === "dashboard" && (
          <div className="animate-fadeIn">
            <h2 className="text-lg font-black mb-5" style={{ color: secondary }}>داشبورد</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
              <StatCard title="محصولات" value={String(products.length)} color={primary} />
              <StatCard title="فروشگاه‌ها" value={String(shops.length)} color="#1976D2" />
              <StatCard title="سفارش‌ها" value={String(orders.length)} color="#4CAF50" />
              <StatCard title="در انتظار" value={String(orders.filter((o) => o.status === "pending").length)} color="#FFA000" />
              <StatCard title="کل فروش" value={formatPrice(orders.reduce((s, o) => s + o.totalAmount, 0))} color="#9C27B0" />
              <StatCard title="کل پورسانت" value={formatPrice(orders.reduce((s, o) => s + (o.commissionAmount || 0), 0))} color="#E91E63" />
            </div>
            <div className="bg-white rounded-2xl p-5">
              <p className="text-xs font-bold text-gray-400 mb-4">آخرین سفارش‌ها</p>
              <div className="space-y-1.5">
                {orders.slice(0, 5).map((o) => (
                  <div key={o.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-xl text-xs">
                    <span className="font-bold" style={{ color: secondary }}>#{o.id} — {o.customerName}</span>
                    <span className="font-bold" style={{ color: primary }}>{formatPrice(o.totalAmount)}</span>
                  </div>
                ))}
                {orders.length === 0 && <p className="text-center text-gray-300 py-6 text-sm">سفارشی ثبت نشده</p>}
              </div>
            </div>
          </div>
        )}

        {/* Products */}
        {activeSection === "products" && (
          <div className="animate-fadeIn">
            <div className="flex justify-between items-center mb-5">
              <h2 className="text-lg font-black" style={{ color: secondary }}>محصولات</h2>
              <button onClick={() => setEditProduct({ name: "", description: "", price: 0, image: "", isBestseller: false, stock: 100 })}
                className="px-4 py-2 rounded-xl text-white text-xs font-bold" style={{ background: primary }}>
                محصول جدید
              </button>
            </div>
            {editProduct && (
              <div className="bg-white rounded-2xl p-5 mb-5 space-y-3 animate-scaleIn">
                <input placeholder="نام محصول" value={editProduct.name} onChange={(e) => setEditProduct({ ...editProduct, name: e.target.value })} className={inputClass} style={{ "--tw-ring-color": primary } as any} />
                <textarea placeholder="توضیحات" value={editProduct.description || ""} onChange={(e) => setEditProduct({ ...editProduct, description: e.target.value })} className={inputClass + " resize-none"} rows={2} style={{ "--tw-ring-color": primary } as any} />
                <div className="grid grid-cols-2 gap-3">
                  <input type="number" placeholder="قیمت (تومان)" value={editProduct.price || ""} onChange={(e) => setEditProduct({ ...editProduct, price: parseInt(e.target.value) || 0 })} className={inputClass} style={{ "--tw-ring-color": primary } as any} />
                  <input type="number" placeholder="موجودی" value={editProduct.stock || ""} onChange={(e) => setEditProduct({ ...editProduct, stock: parseInt(e.target.value) || 0 })} className={inputClass} style={{ "--tw-ring-color": primary } as any} />
                </div>
                <input placeholder="لینک تصویر" value={editProduct.image || ""} onChange={(e) => setEditProduct({ ...editProduct, image: e.target.value })} className={inputClass} dir="ltr" style={{ "--tw-ring-color": primary } as any} />
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={editProduct.isBestseller || false} onChange={(e) => setEditProduct({ ...editProduct, isBestseller: e.target.checked })} className="w-4 h-4 rounded" style={{ accentColor: primary }} />
                  <span className="text-xs font-bold text-gray-600">محصول پرفروش</span>
                </label>
                <div className="flex gap-2">
                  <button onClick={saveProduct} className="flex-1 py-2.5 rounded-xl text-white text-xs font-bold" style={{ background: primary }}>ذخیره</button>
                  <button onClick={() => setEditProduct(null)} className="px-5 py-2.5 rounded-xl border border-gray-200 text-xs font-bold text-gray-500">انصراف</button>
                </div>
              </div>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {products.map((p) => (
                <div key={p.id} className="bg-white rounded-2xl overflow-hidden">
                  <img src={p.image || "https://via.placeholder.com/300"} alt={p.name} className="w-full h-36 object-cover" />
                  <div className="p-4">
                    <h3 className="font-bold text-sm" style={{ color: secondary }}>{p.name}</h3>
                    <p className="text-xs font-bold mt-1" style={{ color: primary }}>{formatPrice(p.price)}</p>
                    <div className="flex items-center gap-2 mt-1">
                      {p.isBestseller && <span className="text-[10px] px-2 py-0.5 rounded-md font-bold" style={{ background: `${primary}15`, color: primary }}>پرفروش</span>}
                      <span className="text-[10px] text-gray-400">موجودی: {p.stock}</span>
                    </div>
                    <div className="flex gap-1.5 mt-3">
                      <button onClick={() => setEditProduct({ ...p })} className="flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1" style={{ background: `${primary}08`, color: primary }}>{SvgIcons.edit} ویرایش</button>
                      <button onClick={() => deleteProduct(p.id)} className="py-2 px-3 rounded-lg bg-red-50 text-red-400">{SvgIcons.trash}</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Shops */}
        {activeSection === "shops" && (
          <div className="animate-fadeIn">
            <div className="flex justify-between items-center mb-5">
              <h2 className="text-lg font-black" style={{ color: secondary }}>فروشگاه‌ها</h2>
              <button onClick={() => setEditShop({ name: "", slug: "", image: "", bannerImage: "", username: "", password: "", commissionRate: 10 })}
                className="px-4 py-2 rounded-xl text-white text-xs font-bold" style={{ background: primary }}>فروشگاه جدید</button>
            </div>
            {editShop && (
              <div className="bg-white rounded-2xl p-5 mb-5 space-y-3 animate-scaleIn">
                <div className="grid grid-cols-2 gap-3">
                  <input placeholder="نام فروشگاه" value={editShop.name} onChange={(e) => setEditShop({ ...editShop, name: e.target.value })} className={inputClass} style={{ "--tw-ring-color": primary } as any} />
                  <input placeholder="شناسه URL" value={editShop.slug} onChange={(e) => setEditShop({ ...editShop, slug: e.target.value })} className={inputClass} dir="ltr" style={{ "--tw-ring-color": primary } as any} />
                </div>
                <input placeholder="لینک تصویر" value={editShop.image || ""} onChange={(e) => setEditShop({ ...editShop, image: e.target.value })} className={inputClass} dir="ltr" style={{ "--tw-ring-color": primary } as any} />
                <input placeholder="لینک بنر" value={editShop.bannerImage || ""} onChange={(e) => setEditShop({ ...editShop, bannerImage: e.target.value })} className={inputClass} dir="ltr" style={{ "--tw-ring-color": primary } as any} />
                <div className="grid grid-cols-3 gap-3">
                  <input placeholder="نام کاربری" value={editShop.username} onChange={(e) => setEditShop({ ...editShop, username: e.target.value })} className={inputClass} dir="ltr" style={{ "--tw-ring-color": primary } as any} />
                  <input type="password" placeholder={editShop.id ? "رمز جدید" : "رمز عبور"} value={editShop.password || ""} onChange={(e) => setEditShop({ ...editShop, password: e.target.value })} className={inputClass} dir="ltr" style={{ "--tw-ring-color": primary } as any} />
                  <input type="number" placeholder="پورسانت %" value={editShop.commissionRate || ""} onChange={(e) => setEditShop({ ...editShop, commissionRate: parseInt(e.target.value) || 0 })} className={inputClass} style={{ "--tw-ring-color": primary } as any} />
                </div>
                <div className="flex gap-2">
                  <button onClick={saveShop} className="flex-1 py-2.5 rounded-xl text-white text-xs font-bold" style={{ background: primary }}>ذخیره</button>
                  <button onClick={() => setEditShop(null)} className="px-5 py-2.5 rounded-xl border border-gray-200 text-xs font-bold text-gray-500">انصراف</button>
                </div>
              </div>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {shops.map((s) => (
                <div key={s.id} className="bg-white rounded-2xl overflow-hidden">
                  <img src={s.image || "https://via.placeholder.com/300x150"} alt={s.name} className="w-full h-32 object-cover" />
                  <div className="p-4">
                    <h3 className="font-bold text-sm" style={{ color: secondary }}>{s.name}</h3>
                    <p className="text-[11px] text-gray-400 mt-0.5" dir="ltr">/{s.slug}</p>
                    <div className="grid grid-cols-3 gap-2 mt-3 text-center">
                      <div className="rounded-lg p-2" style={{ background: `${primary}08` }}>
                        <p className="text-[10px] text-gray-500">پورسانت</p>
                        <p className="font-black text-xs" style={{ color: primary }}>{s.commissionRate}%</p>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-2">
                        <p className="text-[10px] text-gray-500">کل درآمد</p>
                        <p className="font-bold text-[10px]" style={{ color: secondary }}>{formatPrice(s.totalEarnings || 0)}</p>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-2">
                        <p className="text-[10px] text-gray-500">واریز شده</p>
                        <p className="font-bold text-[10px]" style={{ color: secondary }}>{formatPrice(s.paidEarnings || 0)}</p>
                      </div>
                    </div>
                    <button onClick={() => setEditShop({ ...s, password: "" })}
                      className="w-full mt-3 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1"
                      style={{ background: `${primary}08`, color: primary }}>
                      {SvgIcons.edit} ویرایش
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Orders */}
        {activeSection === "orders" && (
          <div className="animate-fadeIn">
            <h2 className="text-lg font-black mb-5" style={{ color: secondary }}>سفارش‌ها</h2>
            {editOrder && (
              <div className="bg-white rounded-2xl p-5 mb-5 space-y-3 animate-scaleIn">
                <p className="text-xs font-bold text-gray-400">ویرایش سفارش #{editOrder.id}</p>
                <select value={editOrder.status} onChange={(e) => setEditOrder({ ...editOrder, status: e.target.value })} className={inputClass} style={{ "--tw-ring-color": primary } as any}>
                  <option value="pending">در انتظار</option>
                  <option value="processing">در حال پردازش</option>
                  <option value="shipped">ارسال شده</option>
                  <option value="delivered">تحویل شده</option>
                </select>
                <input placeholder="لینک پیگیری" value={editOrder.trackingLink || ""} onChange={(e) => setEditOrder({ ...editOrder, trackingLink: e.target.value })} className={inputClass} dir="ltr" style={{ "--tw-ring-color": primary } as any} />
                <div className="flex gap-2">
                  <button onClick={updateOrder} className="flex-1 py-2.5 rounded-xl text-white text-xs font-bold" style={{ background: primary }}>ذخیره</button>
                  <button onClick={() => setEditOrder(null)} className="px-5 py-2.5 rounded-xl border border-gray-200 text-xs font-bold text-gray-500">انصراف</button>
                </div>
              </div>
            )}
            <div className="space-y-2.5">
              {orders.map((o) => {
                const statusMap: Record<string, { l: string; c: string }> = { pending: { l: "در انتظار", c: "#FFA000" }, processing: { l: "پردازش", c: "#1976D2" }, shipped: { l: "ارسال شده", c: "#4CAF50" }, delivered: { l: "تحویل شده", c: "#2E7D32" } };
                const st = statusMap[o.status || "pending"] || statusMap.pending;
                const shop = shops.find((s) => s.id === o.shopId);
                const items = o.items as any[];
                return (
                  <div key={o.id} className="bg-white rounded-2xl p-5">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold" style={{ color: secondary }}>#{o.id}</span>
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold text-white" style={{ background: st.c }}>{st.l}</span>
                      </div>
                      <button onClick={() => setEditOrder({ ...o })} className="text-gray-300 hover:text-gray-500 transition-colors">{SvgIcons.edit}</button>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs mb-2">
                      <div><span className="text-gray-400">مشتری: </span><span className="font-bold">{o.customerName}</span></div>
                      <div><span className="text-gray-400">تلفن: </span><span className="font-bold" dir="ltr">{o.customerPhone}</span></div>
                      <div><span className="text-gray-400">فروشگاه: </span><span className="font-bold">{shop?.name || "-"}</span></div>
                      <div><span className="text-gray-400">ارسال: </span><span className="font-bold">{o.shippingMethod === "post" ? "پست" : "تیپاکس"}</span></div>
                    </div>
                    <p className="text-xs text-gray-400 mb-2"><span>آدرس: </span>{o.customerAddress}</p>
                    <div className="flex flex-wrap gap-1 mb-3">
                      {items?.map((item: any, i: number) => (
                        <span key={i} className="text-[10px] bg-gray-50 px-2 py-1 rounded-md font-bold">{item.name} ×{item.quantity}</span>
                      ))}
                    </div>
                    <div className="flex justify-between pt-3 border-t border-gray-50 text-xs">
                      <span className="text-gray-400">پورسانت: {formatPrice(o.commissionAmount || 0)}</span>
                      <span className="font-black" style={{ color: primary }}>{formatPrice(o.totalAmount)}</span>
                    </div>
                  </div>
                );
              })}
              {orders.length === 0 && <div className="text-center py-16"><p className="text-gray-300 text-sm">سفارشی ثبت نشده</p></div>}
            </div>
          </div>
        )}

        {/* Payouts */}
        {activeSection === "payouts" && (
          <div className="animate-fadeIn">
            <h2 className="text-lg font-black mb-5" style={{ color: secondary }}>ثبت واریز پورسانت</h2>
            <div className="bg-white rounded-2xl p-5 space-y-3">
              <select value={payoutForm.shopId} onChange={(e) => setPayoutForm({ ...payoutForm, shopId: parseInt(e.target.value) })} className={inputClass} style={{ "--tw-ring-color": primary } as any}>
                <option value={0}>انتخاب فروشگاه</option>
                {shops.map((s) => <option key={s.id} value={s.id}>{s.name} (مانده: {formatPrice((s.totalEarnings || 0) - (s.paidEarnings || 0))})</option>)}
              </select>
              <input type="number" placeholder="مبلغ (تومان)" value={payoutForm.amount || ""} onChange={(e) => setPayoutForm({ ...payoutForm, amount: parseInt(e.target.value) || 0 })} className={inputClass} style={{ "--tw-ring-color": primary } as any} />
              <input placeholder="توضیحات" value={payoutForm.description} onChange={(e) => setPayoutForm({ ...payoutForm, description: e.target.value })} className={inputClass} style={{ "--tw-ring-color": primary } as any} />
              <button onClick={processPayout} disabled={!payoutForm.shopId || !payoutForm.amount}
                className="w-full py-3 rounded-xl text-white text-sm font-bold disabled:opacity-40" style={{ background: primary }}>ثبت واریز</button>
            </div>
          </div>
        )}

        {/* Banners */}
        {activeSection === "banners" && (
          <div className="animate-fadeIn">
            <h2 className="text-lg font-black mb-5" style={{ color: secondary }}>مدیریت بنرها</h2>
            <div className="bg-white rounded-2xl p-5 mb-5 space-y-3">
              <p className="text-xs font-bold text-gray-400">افزودن بنر جدید</p>
              <select value={newBanner.type} onChange={(e) => setNewBanner({ ...newBanner, type: e.target.value })} className={inputClass} style={{ "--tw-ring-color": primary } as any}>
                <option value="slider">اسلایدر</option>
                <option value="bottom">بنر پایین</option>
              </select>
              <input placeholder="لینک تصویر" value={newBanner.image} onChange={(e) => setNewBanner({ ...newBanner, image: e.target.value })} className={inputClass} dir="ltr" style={{ "--tw-ring-color": primary } as any} />
              <input type="number" placeholder="ترتیب" value={newBanner.sortOrder} onChange={(e) => setNewBanner({ ...newBanner, sortOrder: parseInt(e.target.value) || 0 })} className={inputClass} style={{ "--tw-ring-color": primary } as any} />
              <button onClick={addBanner} className="w-full py-2.5 rounded-xl text-white text-xs font-bold" style={{ background: primary }}>افزودن</button>
            </div>
            <p className="text-xs font-bold text-gray-400 mb-3">اسلایدر</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
              {sliderBanners.map((b) => (
                <div key={b.id} className="relative rounded-xl overflow-hidden group">
                  <img src={b.image} alt="" className="w-full h-28 object-cover" />
                  <button onClick={() => deleteBanner("slider", b.id)} className="absolute top-2 left-2 w-7 h-7 rounded-lg bg-black/50 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm">{SvgIcons.close}</button>
                </div>
              ))}
            </div>
            <p className="text-xs font-bold text-gray-400 mb-3">بنر پایین</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {bottomBanners.map((b) => (
                <div key={b.id} className="relative rounded-xl overflow-hidden group">
                  <img src={b.image} alt="" className="w-full h-28 object-cover" />
                  <button onClick={() => deleteBanner("bottom", b.id)} className="absolute top-2 left-2 w-7 h-7 rounded-lg bg-black/50 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm">{SvgIcons.close}</button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Settings */}
        {activeSection === "settings" && (
          <div className="animate-fadeIn">
            <h2 className="text-lg font-black mb-5" style={{ color: secondary }}>تنظیمات</h2>
            <div className="bg-white rounded-2xl p-5 space-y-5">
              <div>
                <p className="text-xs font-bold text-gray-400 mb-3">رنگ‌های سایت</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {[
                    { key: "primary_color", label: "رنگ اصلی", def: "#FF1744" },
                    { key: "secondary_color", label: "رنگ ثانویه", def: "#37474F" },
                    { key: "accent_color", label: "رنگ تاکیدی", def: "#FF5252" },
                  ].map((c) => (
                    <div key={c.key}>
                      <label className="block text-[11px] font-bold mb-1.5 text-gray-500">{c.label}</label>
                      <div className="flex items-center gap-2">
                        <input type="color" value={settings[c.key] || c.def} onChange={(e) => setSettings({ ...settings, [c.key]: e.target.value })} className="w-10 h-10 rounded-lg cursor-pointer border-0 p-0" />
                        <input type="text" value={settings[c.key] || c.def} onChange={(e) => setSettings({ ...settings, [c.key]: e.target.value })} className="flex-1 px-3 py-2 rounded-lg bg-gray-50 border border-gray-100 text-xs" dir="ltr" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="border-t border-gray-100 pt-4">
                <p className="text-xs font-bold text-gray-400 mb-3">متن‌ها</p>
                <div>
                  <label className="block text-[11px] font-bold mb-1.5 text-gray-500">عنوان بخش پرفروش‌ترین‌ها</label>
                  <input type="text" value={settings.bestseller_title || ""} onChange={(e) => setSettings({ ...settings, bestseller_title: e.target.value })} className={inputClass} style={{ "--tw-ring-color": primary } as any} />
                </div>
              </div>
              <button onClick={saveSettings} className="w-full py-3 rounded-xl text-white text-sm font-bold" style={{ background: primary }}>ذخیره تنظیمات</button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function StatCard({ title, value, color }: { title: string; value: string; color: string }) {
  return (
    <div className="bg-white rounded-2xl p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="w-2 h-2 rounded-full" style={{ background: color }} />
      </div>
      <p className="text-[10px] text-gray-400 font-bold">{title}</p>
      <p className="font-black text-sm mt-0.5" style={{ color }}>{value}</p>
    </div>
  );
}
